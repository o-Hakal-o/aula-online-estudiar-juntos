An implementation of the Chrome Game (http://www.trex-game.skipser.com/) in ARM assembly. 

Written for the STM32F207 Microcontroller in the IAR Workbench IDE.

![Preview](https://github.com/mgerdes/dinosaur-game-assembly/blob/master/preview.gif?raw=true)
