#pragma once

#define CHARACTER_WIDTH 10
#define CHARACTER_HEIGHT 20

        EXTERN GAME_Draw_Character
        EXTERN GAME_Clear_Character
        EXTERN GAME_Set_Jumping
        EXTERN GAME_Init
        EXTERN GAME_Update

